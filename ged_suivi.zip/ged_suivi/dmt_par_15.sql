﻿select debut_typage.id_pli,dt_debut_typage,dt_fin_typage,
(date_part('epoch',dt_fin_typage::timestamp) - date_part('epoch',dt_debut_typage::timestamp))/ 60 sec
 from (
SELECT max(dt_event) dt_debut_typage,id_pli
  FROM public.histo_pli
  where flag_traitement in(1) and dt_event::date = '2020-01-28'
  group by id_pli
order by id_pli desc 
) debut_typage
left join (

SELECT max(dt_event) dt_fin_typage,id_pli
  FROM public.histo_pli
  where flag_traitement in(2) and dt_event::date = '2020-01-28'
  group by id_pli
order by id_pli desc 
) fin_typage on fin_typage.id_pli = debut_typage.id_pli
