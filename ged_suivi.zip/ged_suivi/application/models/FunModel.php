<?php
    if ( ! defined('BASEPATH')) exit('No direct script access allowed');
    class FunModel extends CI_Model{
        public function view($url,$page,$data){
            $this->load->view($url.'/header',$data);
            $this->load->view($url.'/'.$page,$data);
            $this->load->view('footer');
        }

        public function tabToStr($date){
            $result="";
            foreach($date as $t){

                if(substr($t,-2)%5!=0){
                    
                    $y=intval(substr($t,-2))-substr($t,-2)%5;
                    if($y){
                        $x=substr($t,0,-2).strval($y);
                    }else{
                        $x=substr($t,0,-2).'00';
                    }
                    
                }
                else{
                    $x=$t;
                }
                $result.=",'".$x."'";
            }

            return $result;
        }


        public function tabToInt($s1){
            $result="";
            foreach($s1 as $t){
                $result.= ",".$t;
            }
            return $result;
        }

     
    }