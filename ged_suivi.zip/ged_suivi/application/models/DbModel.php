<?php
    if ( ! defined('BASEPATH')) exit('No direct script access allowed');
    class DbModel extends CI_Model{
        function __construct(){
            parent::__construct();
            $this->load->database();
        }
        public function getNat($temp){
            $query=$this->db->get($temp);
            return $query->result_array();
            
        }
        public function getNomNat($id,$temp){
            $query=$this->db->get($temp);
            $tab= $query->result_array();
            foreach($tab as $t){
                if($t['id']==$id){
                    return $t['libelle'];
                }
            }
            return NULL;
        }
        public function getAll($temp){
            $query=$this->db->get($temp);
            $tab=$query->result_array();
            $res=array();
            $result=array();
            $i=0;
            foreach($tab as $t){
               $res[$i++]=substr($t['heure'], 0, 5);
            }
            $i=0;
            $resulta=array();
            foreach($tab as $t){
                $result['id']=$t['id'];
                $result['date_traitement']=$t['date_traitement'];
                $result['heure']=$res[$i++];
                $result['societe']=$t['societe'];
                $result['nature_traitement']=$t['nature_traitement'];
                $result['pli_total']=$t['pli_total'];
                $result['nb_pli_type']=$t['nb_pli_type'];
                $result['duree_typage']=$t['duree_typage'];
                $result['nb_pli_saisie']=$t['nb_pli_saisie'];
                $result['duree_saisie']=$t['duree_saisie'];
                $result['now']=$t['now'];
                $result['temps']=$t['temps'];
                $resulta[]=$result;
            }

            return $resulta;
        }

        public function PliSocType($n,$tab){
            $all=$this->DbModel->triTab($tab);
            $s1=array();
            foreach($all as $a){
                if($a['societe']==$n){
                    $s1[]=$a['nb_pli_type'];
                }
            }
            return $s1;
        }
        public function PliSocSai($n,$tab){
            $all=$this->DbModel->triTab($tab);
            $s1=array();
            foreach($all as $a){
                if($a['societe']==$n){
                    $s1[]=$a['nb_pli_saisie'];
                }
            }
            return $s1;
        }

        public function PliSocSai3($tab){
            $all=$this->DbModel->triTab($tab);
            $s1=array();
            foreach($all as $a){
                if(!$a['societe']){
                    $s1[]=$a;
                }
            }
            return $s1;
        }
        public function PliSocType3($tab){
            $all=$this->DbModel->triTab($tab);
            $s1=array();
            foreach($all as $a){
                if(!$a['societe']){
                    $s1[]=$a;
                }
            }
            return $s1;
        }

        /*public function getTable2($table){
            $all=$this->DbModel->getAll('suivi_bayard_traitement');
            $saisi=array();
            foreach($all as $a){
                $saisi[]=$a[$table];
            }
            return $saisi;
        }*/

        public function getTable($col){
            $Q=" SELECT '$col'
            FROM suivi_bayard_traitement
             ";
         $qe=$this->db->query($Q);
         return $qe->result_array();
        }

      /*  public function trier2(){
            $all=$this->DbModel->getAll('suivi_bayard_traitement');
            $saisi=array();
            $res=array();
            $n=0;
            $res=0;
            foreach($all as $b){
                $saisi[$n]=$b;
                $n++;
            }

            for($i=0;$i<$n-1;$i++){
                for($j=$i+1;$j<$n;$j++){
                    
                    if(date('Y-m-d H:i:s', strtotime($saisi[$i]['date_traitement'].$saisi[$i]['heure']))>date('Y-m-d H:i:s', strtotime($saisi[$j]['date_traitement'].$saisi[$j]['heure']))){
                        $res=$saisi[$i];
                        $saisi[$i]=$saisi[$j];
                        $saisi[$j]=$res;
                    }
                   
                }
            }
            
            return $saisi;
        }*/

        public function trier(){
            $Q=" SELECT *
                FROM suivi_bayard_traitement
                ORDER BY  date_traitement ASC , heure ASC
            ";
             $qe=$this->db->query($Q);
             $tab= $qe->result_array();
             $res=array();
             $result=array();
             $resulta=array();
             $i=0;
             foreach($tab as $t){
                $res[$i]=substr($t['heure'], 0, 5);
                $i++;
             }
             $i=0;
             foreach($tab as $t){
				 //echo '<pre>'; var_dump($t); echo '</pre>'; continue;
                 $result['id']=$t['id'];
                 $result['date_traitement']=$t['date_traitement'];
                 $result['heure']=$res[$i];
                 $result['societe']=$t['societe'];
                 $result['nature_traitement']=$t['nature_traitement'];
                 $result['pli_total']=$t['nb_pli_type'] + $t['nb_pli_saisie'];
                 $result['nb_pli_type']=$t['nb_pli_type'];
                 $result['duree_typage']=$t['duree_typage'];
                 $result['nb_pli_saisie']=$t['nb_pli_saisie'];
                 $result['duree_saisie']=$t['duree_saisie'];
                 $result['now']=$t['now'];
                 $result['temps']=$t['temps'];
                 $i++;
                 $resulta[]=$result;
             }
 
             return $resulta;
        }

        public function triTab($all){
            $saisi=array();
            $n=0;
            $res=0;
            foreach($all as $b){
                $saisi[$n]=$b;
                $n++;
            }

            for($i=0;$i<$n-1;$i++){
                for($j=$i+1;$j<$n;$j++){
                    
                    if(date('Y-m-d H:i:s', strtotime($saisi[$i]['date_traitement'].$saisi[$i]['heure']))>date('Y-m-d H:i:s', strtotime($saisi[$j]['date_traitement'].$saisi[$j]['heure']))){
                        $res=$saisi[$i];
                        $saisi[$i]=$saisi[$j];
                        $saisi[$j]=$res;
                    }
                   
                }
            }

            return $all;
        }
        
    }