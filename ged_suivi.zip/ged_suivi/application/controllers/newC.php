<?php
    class NewC extends CI_Controller{
        public function view(){
            
        }
    }