<?php
defined('BASEPATH') OR exit('No direct script access allowed');
    class Control extends CI_Controller{
        function __construct(){
            parent::__construct();
            
            $this->load->model(site_url('FunModel'));
            $this->load->model(site_url('DbModel'));
        }

        

        public function search($page='affT'){
            $d1=$this->input->post('DateE');
            $h1=$this->input->post('TimeE');
           
            $new_dateE = date('Y-m-d H:i:s', strtotime($d1.$h1));
            $d=$this->input->post('DateF');
            $h=$this->input->post('TimeF');
            $tst=FALSE;
            $soc=$this->input->post('soc');
            $nat=$this->input->post('nat');
            if($d==null){
                $new_dateF=date('Y-m-d H:i:s');
            }
            else{
                if($h==NULL){
                    $h='23:59';
                }
                else{
                    substr($h, 0, 5);
                }
                $new_dateF=date('Y-m-d H:i:s', strtotime($d.$h));
             }

             if($new_dateF<$new_dateE){
                echo '
                <script language="Javascript">
                    alert(" Date Debut: '.$new_dateE.' superieur à Date Fin: '.$new_dateF.' Alors que c est Impossible ");
                </script>';
                 
             }

          
            $res=array();
            $resu=array();
            $result=array();
            $tab=$this->DbModel->trier();
            

            foreach($tab as $a){
                if(date('Y-m-d H:i:s', strtotime($a['date_traitement'].$a['heure']))<=$new_dateF && date('Y-m-d H:i:s', strtotime($a['date_traitement'].$a['heure']))>=$new_dateE){
                    $res[]=$a;
                } 
            }
            if($soc==''){
                $resu=$res;
                $tst=TRUE;
            }
            else{
                foreach($res as $r){
                    foreach($soc as $s){
                        if($r['societe']==''){
                            if($s=='3'){
                                $resu[]=$r;
                                $tst=TRUE;
                            }
                        }
                        else if($r['societe']==$s){
                            $resu[]=$r;
                        }
                    }
                   
                }
            }

            if($nat==''){
                $result=$resu;
            }
            else{
                foreach($resu as $r){
                    foreach($nat as $s){
                        if($r['nature_traitement']==$s){
                            $result[]=$r;                           
                        }
                    }
                    
                }
            }
            $tab1=array();
            foreach($result as $a){
                $tab1[]=$a['date_traitement']."  ".substr($a['heure'], 0, 5);
            }
            $date = array_unique($tab1);
            $da=array();
            $tmp=0;
            foreach($date as $d){
                        if($tmp==date('d-m-Y',strtotime($d))){
                            $da[]=date('d-m-Y H:i',strtotime($d));
                        }
                        else{
                            $da[]=date('d-m-Y H:i',strtotime($d));
                        }
                    $tmp=date('d-m-Y',strtotime($d));
                
            }
            $data['temp']=$d1." ".substr($h1, 0, 5);
            $data['temp2']=$d." ".substr($h, 0, 5);
            
            $data['soc']=$soc;
            $data['date']=$da;
            $data['tst']=$tst;
            $data['s3t']=$this->DbModel->PliSocType3($result);
            $data['s3s']=$this->DbModel->PliSocSai3($result);
            $data['s1']=$this->DbModel->PliSocType(1,$result);
            $data['s2']=$this->DbModel->PliSocType(2,$result);
            $data['s3']=$this->DbModel->PliSocType(NULL,$result);
            $data['sa1']=$this->DbModel->PliSocSai(1,$result);
            $data['sa2']=$this->DbModel->PliSocSai(2,$result);
            $data['sa3']=$this->DbModel->PliSocSai(NULL,$result);
            $data['type']=$result;
            $data['andro']=NULL;
            $data['page']=$page;
            $data['pol']=$d1." ".$h1." ".$d." ".$h." ";
            $data['BUrl']=base_url('Control/search/'.$page);
            $data['reto'] = rand(1000, 5000);
            $this->FunModel->view('affView',$page,$data);
        }

        public function view($page='affT'){
            $izyRht=$this->DbModel->trier();
            $temp='1999-01-01';
            foreach($izyRht as $i){
                if(date('d-m-Y',strtotime($temp))<=date('d-m-Y',strtotime($i['date_traitement']))){
                    $temp=$i['date_traitement'];
                }
            }
            $d1=$temp;
            $h1='00:00';
           
            $new_dateE = date('Y-m-d H:i:s', strtotime($d1.$h1));
            $d=$temp;
            $h='23:59';
            
            $soc[]='';
            $soc[]='1';
            $soc[]='2';
            $nat='';
            if($d==null){
                $new_dateF=date('Y-m-d H:i:s');
            }
            else{
                if($h==NULL){
                    $h='23:59';
                }
                else{
                    substr($h, 0, 5);
                }
                $new_dateF=date('Y-m-d H:i:s', strtotime($d.$h));
             }

          
            $res=array();
            $resu=array();
            $result=array();
            $tab=$this->DbModel->trier();
            

            foreach($tab as $a){
                if(date('Y-m-d H:i:s', strtotime($a['date_traitement'].$a['heure']))<=$new_dateF && date('Y-m-d H:i:s', strtotime($a['date_traitement'].$a['heure']))>=$new_dateE){
                    $res[]=$a;
                } 
            }
            if($soc==''){
                $resu=$res;
            }
            else{
                foreach($res as $r){
                    foreach($soc as $s){
                        if($r['societe']==$s){
                            $resu[]=$r;
                        }
                    }
                   
                }
            }

            if($nat==''){
                $result=$resu;
            }
            else{
                foreach($resu as $r){
                    if($r['nature_traitement']==$nat){
                        $result[]=$r;
                    }
                }
            }
            $tab1=array();
            foreach($result as $a){
                $tab1[]=$a['date_traitement']."  ".substr($a['heure'], 0, 5);
            }
            $date = array_unique($tab1);
            $da=array();
            $tmp=0;
            foreach($date as $d){
                if($tmp==date('d-m-Y',strtotime($d))){
                    $da[]=date('d-m-Y H:i',strtotime($d));
                }
                else{
                    $da[]=date('d-m-Y H:i',strtotime($d));
                }
                $tmp=date('d-m-Y',strtotime($d));
            }
            $data['temp']=$d1." ".substr($h1, 0, 5);
            $data['temp2']=$d." ".substr($h, 0, 5);
            if(!$soc){
                $soc[]='TOUS';
            }
            $data['pol']=NULL;
            $data['soc']=$soc;
            $data['date']=$da;
            $data['tst']=TRUE;
            $data['s3t']=$this->DbModel->PliSocType3($result);
            $data['s3s']=$this->DbModel->PliSocSai3($result);
            $data['s1']=$this->DbModel->PliSocType(1,$result);
            $data['s2']=$this->DbModel->PliSocType(2,$result);
            $data['s3']=$this->DbModel->PliSocType(NULL,$result);
            $data['sa1']=$this->DbModel->PliSocSai(1,$result);
            $data['sa2']=$this->DbModel->PliSocSai(2,$result);
            $data['sa3']=$this->DbModel->PliSocSai(NULL,$result);
            $data['type']=$result;
            $data['andro']=NULL;
            $data['page']=$page;
            $data['BUrl']=base_url('Control/search/'.$page);
            $this->FunModel->view('affView',$page,$data);
        }
    }