
           <footer class="page-footer font-small blue pt-4">

<div class="footer-copyright text-center py-3" position="fixed">© 2020 Copyright:
<a href="https://www.vivetic.com/"> vivetic.com</a>  
</div>


</footer>



</body>

</html>