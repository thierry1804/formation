
<br><br><br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h2>Typage</h2>
        <canvas id="myChart2" height="120" width="400" ></canvas>
    </div>
    <div class="col-2"></div>
</div>
<br><br><br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h2>Saisie</h2>
        <canvas id="myChart3" height="120" width="400" ></canvas>
    </div>
    <div class="col-2"></div>
</div>




<script>

var ctx = document.getElementById('myChart2').getContext('2d');
var chart = new Chart(ctx, {
// The type of chart we want to create
type: 'line',

// The data for our dataset
data: {
labels: [''
 <?php 
    foreach($date as $t){
        echo ",'".$t."'";
    }
?>],
datasets: [{
label: 'Bayard',
//backgroundColor: 'rgb(255, 99, 132)',

borderColor: 'rgb(255, 99, 132)',
data: [0
<?php
    foreach($s1 as $t){
            echo ",".$t;
        }
?>

],

},{
label: 'Milan',
//backgroundColor: 'rgb(1, 99, 132)',

borderColor: 'rgb(0, 99, 132)',
data: [0
<?php
    foreach($s2 as $t){
            echo ",".$t;
        }
?>
],
}

]



},


// Configuration options go here
options: {}
});
</script>
<script>

var ctx = document.getElementById('myChart3').getContext('2d');
var chart = new Chart(ctx, {
// The type of chart we want to create
type: 'line',

// The data for our dataset
data: {
labels: [''
 <?php 
    foreach($date as $t){
        echo ",'".$t."'";
    }
?>],
datasets: [{
label: 'Bayard',
//backgroundColor: 'rgb(255, 99, 132)',

borderColor: 'rgb(255, 99, 132)',
data: [0
<?php
    foreach($sa1 as $t){
            echo ",".$t;
        }
?>

],

},{
label: 'Milan',
//backgroundColor: 'rgb(255, 99, 132)',

borderColor: 'rgb(0, 99, 132)',
data: [0
<?php
    foreach($sa2 as $t){
            echo ",".$t;
        }
?>
],
}

]



},


// Configuration options go here
options: {}
});
</script>

       