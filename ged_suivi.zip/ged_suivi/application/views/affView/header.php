<html>
    <head>
        <title>Recette Bayard</title>
        <meta charset="utf-8">
        <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
        <script src="<?php echo base_url('assets/js/Chart.bundle.js');?>"></script>
        <link href="<?php echo base_url('assets/css/tpicker.css');?>" rel="stylesheet">
        <link rel="icon" href="<?php echo base_url('assets/img/hed.ico');?>"/>
        <script type="text/javascript" src="<?php echo base_url('assets/js/tpicker.js');?>"></script>
        <link href="https://use.fontawesome.com/releases/v5.0.7/css/all.css" rel="stylesheet"> 

        <style>
            body{
              overflow-y: hidden;
              overflow-x: hidden;
            }

            select{
            border:none;
            overflow: hidden;
            font-family:cursive;
            font-style: oblique;
            }

            .menu1 {
              display: block;
              margin: 2px 0;
              width: 100px;
              height: 30px;
              background-color: transparent;
              border: 0px solid #77B5F1;
              border-radius: 5px;
              overflow: hidden;
              cursor: pointer;
              transition: all 0.5s ease-in-out;
              -webkit-transition: all 0.5s ease-in-out;
              -moz-transition: all 0.5s ease-in-out;
              -o-transition: all 0.5s ease-in-out;
              -ms-transition: all 0.5s ease-in-out;
            }

            .menu1 div.barry1 {
              font-family:cursive;
              font-weight : bolder;
              font-style: oblique;
              width: 60px;
              margin: 3px 16px;
            }
            
            .menu1 div.barry1 .bar1 { 
              display: block;
              width: 15px;
              height: 2px;
              margin-top: 2px;
              margin-left: -13px;
              border: 0px;
              background-color: white;
            }

            .dropbtn {
              width: 20px;
              height: 20px;
              padding: 6px;     
              background: dodgerblue;
              border: 1px solid white;
              box-sizing: content-box;
              border-radius: 50%;
              text-indent: 100%;
              color: transparent;
              white-space: nowrap;
              cursor: pointer;
              overflow: hidden;
            }

            .hamburger-menu-button-open {
              top: 50%;
              margin-top: -1px;
              left: 50%;
              margin-left: -12px;
            }

            .dropdown {
              position: relative;
              display: inline-block;
            }

            .dropdown-content { /* */
              display: none;
              left:-29px;        
              position: absolute;
              background-color: #f1f1f1;
              min-width: 92px;
              box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
              z-index: 1;                          
            }

            .dropdown-content a {
              font-family:cursive;
              font-weight : bolder;
              font-style: oblique;
              font-size: 17px;
              color: black;
              padding-top: 10px ;
              padding-left: 17px ;
              padding-bottom: 10px ;
              text-decoration: none;
              display: block;
            }

            .dropdown-content a:hover {
              border-radius:5px; 
              background-color: dodgerblue;
              }

            .dropdown:hover .dropdown-content {
                border-radius:5px;
                display: block;
            }

            .dropdown:hover .dropbtn {background-color:#6495ED;}
            hamburger-menu-button-open, 
            .hamburger-menu-button-open::before, 
            .hamburger-menu-button-open::after {
              position: absolute;
              width: 24px;
              height: 2px;
              background: #fff;
              border-radius: 4px;
              -webkit-transition: all 0.3s;
              transition: all 0.3s;
            }

            .hamburger-menu-button-open::before, 
            .hamburger-menu-button-open::after {
              left: 0;
              content: "";
            }

            .hamburger-menu-button-open::before {
              top: 6px;
            }

            .hamburger-menu-button-open::after {
              bottom: 6px;
            }

            .titre{
              color:black;
              font-family:cursive;
              font-weight : bolder;
              font-style: oblique;
              padding-top: 10px;
              padding-left:60px;
            }

            /* For desktop: */
            .lol-1 {width: 2%;}
              .lol-2 {width: 16.66%;height: 50%;}
              .lol-3 {width: 0.2%;}
              .lol-4 {width: 33.33%;}
              .lol-5 {width: 41.66%;height: 50%;}
              .lol-6 {width: 50%;height: 50%;}
              .lol-7 {width: 58.33%;height: 50%;}
              .lol-8 {width: 66.66%;height: 50%;}
              .lol-9 {width: 75%;height: 100%;}
              .lol-10 {width: 96%; }
              .lol-11 {width: 91.66%;height: 50%;}
              .lol-12 {width: 100%;height: 50%;}
              .lol-13{width: 96%; height: 120px;}
              
            @media only screen and (max-width: auto)  {
              /* For mobile phones: */
              [class*="lol-"] {
                width: 100%;
                height: 100%
              }
            }
          

            #mmeennuu {
              display: none;
              border-radius: 50%;
              transition: all 1s;
              z-index: 4;
              box-shadow: 0 0 25px 0 rgba(0, 0, 0, 0.4);
            }

            #mmeennuu:checked ~ .menu {
              width: auto;
              height: auto;
              border-radius: 10px;
              background-color: #FFFFFF;
              border: 2px solid dodgerblue;
              
            }

            #mmeennuu:checked ~ .menu > ul {
              display: block;
              opacity: 1;
            }

            #mmeennuu:checked ~ .menu > .barry {
              display: none;
            }

            .menu {
              display: block;
              margin: 2px 0;
              width: 100px;
              height: 40px;
              background-color: white;
              border: 2px solid #77B5F1;
              border-radius: 6px;
              overflow: hidden;
              cursor: pointer;
              transition: all 0.5s ease-in-out;
              -webkit-transition: all 0.5s ease-in-out;
              -moz-transition: all 0.5s ease-in-out;
              -o-transition: all 0.5s ease-in-out;
              -ms-transition: all 0.5s ease-in-out;
            }

            .menu:hover{
              background-color: #CECECE;
              box-shadow: 0 0 10px 0 dodgerblue inset, 0 0 10px 4px #EFEFEF;
            }

            .menu div.barry {
              font-family:cursive;
              font-weight : bolder;
              font-style: oblique;
              font-size: 14px;
              width: 60px;
              margin: 10px 7px;
            }
           
            .menu div.barry .bar {
              display: block;
              width: 100%;
              height: 5px;
              margin-top: 3px;
              border-radius: 2px;
              background-color: #fff;
            }

            .menu ul {
              opacity: 0;
              display: none;
              background-color: transparent;
              transition: all 0.5s ease-in-out;
              -webkit-transition: all 0.5s ease-in-out;
              -moz-transition: all 0.5s ease-in-out;
              -o-transition: all 0.5s ease-in-out;
              -ms-transition: all 0.5s ease-in-out;
              list-style-type: none;
              padding: 0;
              width: auto;
              height: auto;
              text-align: center;
              margin-bottom: 0;
            
            }

            .menu ul li { /*s ds c*/
              
              display: inline-block;
              width: 145px;
              height: 60px;
            }

            .btnR{
              width: 100px;
              height: 40px;
              border-radius: 6px;
              font-family:cursive;
              font-weight : bolder;
              font-style: oblique;
              font-size: 15px;
              color:dodgerblue;
              border-color:dodgerblue;
              background-color: white;
            }

            .btnR:hover{
              background-color: #CECECE;
              box-shadow: 0 0 10px 0 dodgerblue inset, 0 0 10px 4px #CECECE;
            }

            .menu ul li a {
              padding-top: 0px;
              font-family:cursive;
              font-weight : bolder;
              font-style: oblique;
              text-decoration: none;
              display: inline-block;
              padding: auto auto;
              color: dodgerblue;
              font-size: 10px;
              transition: all 0.3s ease-in-out;
              -webkit-transition: all 0.3s ease-in-out;
              -moz-transition: all 0.3s ease-in-out;
              -o-transition: all 0.3s ease-in-out;
              -ms-transition: all 0.3s ease-in-out;
            }

            .menu ul li a:hover {
              border-color: dodgerblue;
            }

            .menu ul li a:target {
              border-bottom-color: dodgerblue;
            }
       
            .tabilao{
              margin-top:0px ;
              margin-bottom:0px ;
              border: 5px ;
              border-color: #77B5FE;
              height: 285px;
              overflow-y: scroll;
            }

            @import url("https://fonts.googleapis.com/css?family=Inconsolata:700");
            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }

            .container {
              position: relative;
              margin: auto;
              top: 20px;
              left: 20px;
              right: 0;
              bottom: 0;
              width: 100px;
              height: 100px;
            }

            .container .search {
              position: absolute;
              margin: auto;
              top: 0;
              right: 0;
              bottom: 0;
              left: 0;
              width: 80px;
              height: 80px;
              background: dodgerblue;
              border-radius: 50%;
              transition: all 1s;
              z-index: 4;
              box-shadow: 0 0 25px 0 rgba(0, 0, 0, 0.4);
            }

            .container .search:hover {
              cursor: pointer;
            }

            .container .search::before {
              content: "";
              position: absolute;
              margin: auto;
              top: 22px;
              right: 0;
              bottom: 0;
              left: 22px;
              width: 12px;
              height: 2px;
              background: white;
              transform: rotate(45deg);
              transition: all .5s;
            }

            .container .search::after {
              content: "";
              position: absolute;
              margin: auto;
              top: -5px;
              right: 0;
              bottom: 0;
              left: -5px;
              width: 25px;
              height: 25px;
              border-radius: 50%;
              border: 2px solid white;
              transition: all .5s;
            }

            .container input {
              font-family: 'Inconsolata', monospace;
              position: absolute;
              margin: auto;
              top: 0;
              right: 0;
              bottom: 0;
              left: 0;
              width: 50px;
              height: 50px;
              outline: none;
              border: none;
              background: crimson;
              color: white;
              text-shadow: 0 0 10px crimson;
              padding: 0 80px 0 20px;
              border-radius: 30px;
              box-shadow: 0 0 25px 0 crimson, 0 20px 25px 0 rgba(0, 0, 0, 0.2);
              transition: all 1s;
              opacity: 0;
              z-index: 5;
              font-weight: bolder;
              letter-spacing: 0.1em;
            }

            .container input:hover {
              cursor: pointer;
            }

            .container input:focus {
              width: 3000px;
              opacity: 1;
              cursor: text;
            }

            .container input:focus ~ .search {
              right: -250px;
              background: #151515;
              z-index: 6;
            }

            .container input:focus ~ .search::before {
              top: 0;
              left: 0;
              width: 25px;
            }

            .container input:focus ~ .search::after {
              top: 0;
              left: 0;
              width: 25px;
              height: 2px;
              border: none;
              background: white;
              border-radius: 0%;
              transform: rotate(-45deg);
            }

            .container input::placeholder {
              color: white;
              opacity: 0.5;
              font-weight: bolder;
            }

            .ex1 {
              width: auto;
              height: 250px;
              overflow: scroll;
            }

            /* Let's get this party started */
            ::-webkit-scrollbar {
                width: 12px;
            }
            
            /* Track */
            ::-webkit-scrollbar-track {
                -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
                -webkit-border-radius: 10px;
                border-radius: 10px;
            }
            
            /* Handle */
            ::-webkit-scrollbar-thumb {
                -webkit-border-radius: 10px;
                border-radius: 10px;
                background: dodgerblue; 
                -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5); 
                
            }
            
            ::-webkit-scrollbar-thumb:window-inactive {
              background: dodgerblue; 
            }
                
            @media only screen and (max-width: 600px) {
              /* For mobile phones: */
              [class="ex1"] {
                height: 900px;
              }
              .rTable{   
                font-size: 9px;     
              }
             
             
            }
            .iotitre{
              float: right;
              clear: left;
              margin-left: auto;
            }

            [type="date"] {
        background:#fff url(https://cdn1.iconfinder.com/data/icons/cc_mono_icon_set/blacks/16x16/calendar_2.png)  97% 50% no-repeat ;
      }
      [type="date"]::-webkit-inner-spin-button {
        display: none;
      }
      [type="date"]::-webkit-calendar-picker-indicator {
        opacity: 0;
      }
            
           
           
          
        </style>

        <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
        <script>
          $(document).ready(function(){
          setInterval(function(){
          $("#screen").load('banners.php')
          }, 1000);
          });
        </script>



    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />



    </head>

    <body>  
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <a class="navbar-brand" href="#">Recette Bayard</a>
                    
            <div class="" id="navbarColor01">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <div class="dropdown">
                            <button class="dropbtn">
                                      <label class='menu1' for='mmeennuu1'>
                                        <div class='barry1'>
                                          <span class='bar1'></span>
                                          <span class='bar1'></span>
                                          <span class='bar1'></span>
                                        </div>
                            </button>
                            <div class="dropdown-content">
                                <a href="<?php echo base_url('Control/view/affS');?>">Saisie</a>
                                <a href="<?php echo base_url('Control/view/affT');?>">Typage</a>
                            </div>
                        </div>
                    </li>
                </ul>
              </div> 
                            
              <div class="iotitre" >
                  <input type='checkbox' id='mmeennuu' class="form-inline my-2 my-lg-0">
                  <label class='menu' for='mmeennuu'>
                      <div class='barry'>
                          <i class="fas fa-search"><a>&nbsp;Recherche</a></i>     
                      </div>   
                      <ul>
                          <?php
                              $d1=NULL;
                              $h1=NULL;
                              $d2=NULL;
                              $h2=NULL;
                              if($pol){
                                $golan = explode(" ", $pol);
                                $d1=$golan[0];
                                $h1=$golan[1];
                                $d2=$golan[2];
                                $h2=$golan[4];
                              }       
                          ?>

                          <form action='<?php echo base_url("Control/search/$page");?>' method="POST">
                              <li> <a><label class="col-form-label">Traitement du :</label></a></li>
                              <li>  <input type="date" class="form-control" name="DateE" value=<?php echo $d1;?>> </li>
                              
                              <li>  <input id="timepicker" width="140" type="time"  name="TimeE" value=<?php echo $h1;?> /></li>


                              <li><a> <label class="col-form-label">au :</label></a></li>
                              <li><input type="date" class="form-control" name="DateF" value=<?php echo $d2;?>> </li>

                              <li>  <input id="timepicker2" width="140" type="time"  name="TimeF" value=<?php echo $h2;?>> </li>
                              

                              <li><a><label class="col-form-label">Société :</label></a></li>
                              <li> 
                                  <select name="soc[]" class="custom-select form-control" multiple>            
                                      <option value="1">Bayard</option>
                                      <option value="2">Milan</option>
                                      <option value="3">Autre</option>
                                  </select>
                              </li>
                              <li><a><label class="col-form-label">Nature :</label></a></li>
                              <li class="or">
                                  <select name="nat[]" class="custom-select  form-control" multiple>
                                      <?php
                                        $tabNature=$this->DbModel->getNat('type_nature_suivi_bayard_traitement');

                                        foreach($tabNature as $ta){
                                          ?>
                                              <option value="<?php echo $ta['id'];?>"> <?php echo $ta['libelle'];?> </option>
                                          <?php
                                        }
                                      ?>
                                    
                                  </select>
                              </li>
                              <li>
                                  <button type="submit" class="btnR">Chercher</button>
                              </li>
                          </form>        
                      </ul>
                  </label>
              </div>
           <!-- !-->
        </nav>
     

        
    <script>
        $('#timepicker').timepicker({
            uiLibrary: 'bootstrap4'
        });
        $('#timepicker2').timepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>

