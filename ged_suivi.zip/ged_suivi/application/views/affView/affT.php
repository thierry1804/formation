
<div class="row">
    <div class="lol-1"></div>
    <div class="lol-10">
        
    <div class="row">
            <div class="lol-3">
                <i class="	fas fa-file-alt" style="font-size:30px; color:black; margin-top:10px; margin-left:30px"></i> 
            </div>
            <div class="lol-4">
            <h2 class="titre">Typage</h2>
            </div>
        </div>

        <canvas id="tmyChart2" class="banners" height="100" width="400" ></canvas>
    </div>
    <div class="lol-1"></div> 
</div>

<div class="row">
    <div class="lol-1"></div>
        <div class="lol-10">
            <div class="card border-primary mb-3" >
                <div class="row">        
                    <div class="col-12">  
                        <div class="card-header" >
                            <h1>
                                <table class="table table-hover">
                                    <thead class="rTable">
                                        <tr class="table-active">
                                            <th scope="row" width="320">Traitement du</th>
                                            <th scope="row" width="280">Heure</th>
                                            <th scope="row" width="315">Société</th>
                                            <th scope="row" width="400">Nature du traitement</th>                                
                                            <th scope="row" width="340">Pli type</th>
                                            <th scope="row" >Durée</th>                                  
                                        </tr>
                                    </thead>
                                </table>
                            </h1>
                        </div>

                        <div class="card-body ">
                            <div class="tabilao" >
                                <table class="table table-hover">
                                    <thead>                                           
                                    </thead>
                                    <tbody class="rTable">
                                        <?php   foreach($type as $t){ ?>
                                            <tr>
                                                <td  width="325"> <?php echo date('d/m/Y',strtotime($t['date_traitement']));?> </td>                                              
                                                <td  width="280"> <?php   $y=intval(substr(substr($t['heure'], 0, 5),-2))-substr(substr($t['heure'], 0, 5),-2)%5;
                                                if($y){
                                                    $x=substr(substr($t['heure'], 0, 5),0,-2).strval($y);
                                                }
                                                else {
                                                    $x=substr(substr($t['heure'], 0, 5),0,-2)."00";
                                                }
                                                echo $x;?> </td>                                             
                                                <td  width="310"> <?php if($t['societe']==1){echo "Bayard";}else if($t['societe']==2) {echo "Milan";}?> </td>
                                                <td width="420">  <?php echo $this->dbModel->getNomNat($t['nature_traitement'],'type_nature_suivi_bayard_traitement');?></td>                                                  
                                                <td width="330"> <?php echo $t['nb_pli_type'];?> </td>
                                                <td> <?php echo number_format($t['duree_typage'],2);?> </td>                                                 
                                            </tr>
                                        <?php
                                        }
                                        ?> 
                                    </tbody>   
                                </table>
                            </div>
                        </div>                      
                    </div>
                </div>
            </div>
        </div>
        <div class="lol-3"></div>
    </div>
</div>
<?php 
    $s3ss=array();
    if($tst){
        $sss=array();
        $o=0;
        $debS="";
        $debF="";
        foreach($s3t as $ml){
            $debS=date('d-m-Y H:i:s',strtotime($ml['date_traitement'].$ml['heure']));
            break;
        }
        foreach($s3t as $ml){
            $debF=date('d-m-Y H:i:s',strtotime($ml['date_traitement'].$ml['heure']));
            
        }
        
        foreach($s3t as $s){
            $sss[$o]=$s['nb_pli_type'];
            $o++;
        }
        
        $i=0;
        $b=0;
        
        foreach($date as $d){
            if($d>date('d-m-Y H:i:s',strtotime($debS)) && $d<=date('d-m-Y H:i:s',strtotime($debF))){
                
                    if($b<$o){
                            $s3ss[]=$sss[$b];
                    }
                    else{
                        $s3ss[]=0;
                    }
                    $b++; 
                }
            else{
                $s3ss[]=0;
            }    
        }
    }
    $da=array();
    $tmp=0;
    foreach($date as $d){
        if($tmp==date('d-m-Y',strtotime($d))){
            $da[]=date(' H:i',strtotime($d));
        }
        else{
            $da[]=date('d-m-Y',strtotime($d));
        }
        $tmp=date('d-m-Y',strtotime($d));
    }      
?>

<script>

    var ctx = document.getElementById('tmyChart2').getContext('2d');
    var chart = new Chart(ctx, {
        // The type of chart we want to create
        type: 'line',
        // The data for our dataset
        data: {
            labels: [''
                <?php 
                $str=$this->funModel->tabToStr($da);
                echo $str;
                ?>
            ],
            datasets: [         
                {
                    label: 'Bayard',
                    //backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(30,144,255)',
                    data: [0
                        <?php
                            $str=$this->funModel->tabToInt($s1);
                            echo $str;
                        ?>
                    ],
                },{
                    label: 'Milan',
                    //backgroundColor: 'rgb(1, 99, 132)',
                    borderColor: 'rgb(0, 0, 0)',
                    data: [0
                        <?php
                            $str=$this->funModel->tabToInt($s2);
                            echo $str;
                        ?>
                    ],
                },{
                    label: 'Autre',
                    //backgroundColor: 'rgb(1, 99, 132)',
                    borderColor: 'rgb(222, 49, 99)',
                    data: [
                        <?php
                            $str=$this->funModel->tabToInt($s3ss);
                            echo $str;
                        ?>
                    ],
                }
            ]
        },
        // Configuration options go here
        options: {}
    });
</script>

