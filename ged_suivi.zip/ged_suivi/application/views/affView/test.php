<?php
    foreach($tab as $t){
        echo ' ---------------- '.$t['date_traitement'].'--'.$t['heure'];
    }
?>